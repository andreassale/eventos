package com.eventos.evento87;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Evento87ApplicationTests {

	@Test
	void contextLoads() {
	}

}
