package com.eventos.evento87;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Evento87Application {

	public static void main(String[] args) {
		SpringApplication.run(Evento87Application.class, args);
	}

}
